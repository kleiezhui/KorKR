    </main>
    <footer class="main-footer">
        <div class="footer-links">
            <a href="index.php">Вход</a> | 
            <a href="register.php">Регистрация</a> | 
            <a href="support.php">Техническая поддержка</a>
        </div>
        <div class="footer-copy">
            Peace - ИС салона связи
        </div>
    </footer>
</body>
</html>