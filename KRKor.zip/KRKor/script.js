document.addEventListener('DOMContentLoaded', () => {
    const themeToggle = document.getElementById('themeToggle');
    const currentTheme = localStorage.getItem('theme') || 'light';
    
    if (currentTheme === 'dark') {
        document.body.setAttribute('data-theme', 'dark');
        if(themeToggle) themeToggle.checked = true;
    }

    if(themeToggle) {
        themeToggle.addEventListener('change', () => {
            if (themeToggle.checked) {
                document.body.setAttribute('data-theme', 'dark');
                localStorage.setItem('theme', 'dark');
            } else {
                document.body.removeAttribute('data-theme');
                localStorage.setItem('theme', 'light');
            }
        });
    }

    const puzzleGrid = document.getElementById('puzzle-grid');
    const puzzlePool = document.getElementById('puzzle-pool');
    const btnLogin = document.getElementById('btnLogin');
    const captchaSolvedInput = document.getElementById('captchaSolved');
    const attemptsSpan = document.getElementById('puzzle-attempts');
    
    let attempts = 1;
    let targetOrder = [1, 2, 3, 4];
    let currentOrder = [null, null, null, null];
    
    const pieceStyles = {
        1: 'linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%)',
        2: 'linear-gradient(135deg, #a18cd1 0%, #fbc2eb 100%)',
        3: 'linear-gradient(135deg, #84fab0 0%, #8fd3f4 100%)',
        4: 'linear-gradient(135deg, #fccb90 0%, #d57eeb 100%)'
    };

    function initPuzzle() {
        if (!puzzleGrid || !puzzlePool) return;
        puzzleGrid.innerHTML = '';
        puzzlePool.innerHTML = '';
        currentOrder = [null, null, null, null];

        let shuffled = [1, 2, 3, 4].sort(() => Math.random() - 0.5);
        
        shuffled.forEach(id => {
            const piece = document.createElement('div');
            piece.className = 'puzzle-piece';
            piece.style.background = pieceStyles[id];
            piece.dataset.id = id;
            piece.addEventListener('click', () => movePieceToGrid(id, piece));
            puzzlePool.appendChild(piece);
        });

        for (let i = 0; i < 4; i++) {
            const slot = document.createElement('div');
            slot.className = 'puzzle-piece empty';
            slot.dataset.index = i;
            slot.addEventListener('dragover', e => e.preventDefault());
            slot.addEventListener('drop', (e) => {
                e.preventDefault();
                const id = parseInt(e.dataTransfer.getData('text/plain'));
                const poolPiece = puzzlePool.querySelector(`[data-id="${id}"]`);
                if(poolPiece) movePieceToGrid(id, poolPiece, slot);
            });
            puzzleGrid.appendChild(slot);
        }
    }

    function movePieceToGrid(id, sourceElement, targetSlot = null) {
        if (!targetSlot) {
            targetSlot = Array.from(puzzleGrid.children).find(slot => slot.classList.contains('empty'));
        }
        
        if (targetSlot) {
            targetSlot.classList.remove('empty');
            targetSlot.style.background = pieceStyles[id];
            targetSlot.dataset.id = id;
            currentOrder[targetSlot.dataset.index] = id;
            sourceElement.remove();
            checkPuzzle();
        }
    }

    if (puzzlePool) {
        puzzlePool.addEventListener('dragstart', e => {
            if(e.target.classList.contains('puzzle-piece')) {
                e.dataTransfer.setData('text/plain', e.target.dataset.id);
            }
        });
    }

    function checkPuzzle() {
        const isComplete = currentOrder.every((val, index) => val === targetOrder[index]);
        if (isComplete) {
            captchaSolvedInput.value = 'true';
            btnLogin.disabled = false;
            puzzleGrid.style.borderColor = 'var(--success-border)';
        } else {
            captchaSolvedInput.value = 'false';
            btnLogin.disabled = true;
            puzzleGrid.style.borderColor = 'var(--border-color)';
        }
    }

    window.resetPuzzle = function() {
        if (captchaSolvedInput && captchaSolvedInput.value === 'true') return;
        attempts++;
        if (attemptsSpan) attemptsSpan.innerText = `${attempts} / 3`;
        if (attempts > 3) {
            alert("Превышено количество попыток ввода капчи! Учетная запись будет заблокирована.");
            window.location.href = "auth.php?block=1"; 
        }
        initPuzzle();
    };

    if (puzzleGrid) initPuzzle();

    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('success') === '1') {
        const successPanel = document.getElementById('successState');
        if (successPanel) successPanel.style.display = 'flex';
    }
});