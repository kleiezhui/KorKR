<?php require 'header.php'; ?>

<div class="grid-2-col">
    <!-- Левая колонка с формой -->
    <div class="card">
        <h2>Техническая поддержка Peace</h2>
        <p class="text-muted mt-2 mb-4">Опишите проблему, укажите контакт для ответа и прикрепите файл.</p>
        
        <form action="#" method="POST" onsubmit="event.preventDefault(); document.getElementById('supportSuccess').style.display='flex';">
            <div class="form-group">
                <label>Логин или контакт для ответа</label>
                <input type="text" placeholder="Введите логин, номер телефона или email" required>
            </div>
            <div class="form-group">
                <label>Тема / категория</label>
                <select required>
                    <option value="">Выберите тему обращения</option>
                    <option value="login">Проблема со входом</option>
                    <option value="error">Ошибка в работе системы</option>
                </select>
            </div>
            <div class="form-group">
                <label>Описание проблемы</label>
                <textarea rows="4" placeholder="Опишите, что происходит..." required></textarea>
            </div>
            
            <div class="form-group">
                <label>Прикрепить файл</label>
                <div class="file-drop">📎 Перетащите файл сюда или выберите его на компьютере</div>
            </div>

            <div class="alert alert-warning">
                <span class="icon">!</span>
                <div>
                    <strong>Важно:</strong><br> Не отправляйте в обращении пароль, 2FA-код, SMS-код. Поддержка поможет восстановить доступ безопасно.
                </div>
            </div>

            <button type="submit" class="btn btn-primary">Отправить обращение ✈</button>
        </form>
    </div>

    <!-- Правая колонка (сайдбар) -->
    <div class="sidebar">
        <div class="card">
            <h3>Быстрая помощь</h3>
            <div class="help-item mt-4">
                <strong>Блокировка после 3 неверных паролей</strong>
                <p class="small text-muted mt-2">После 3 ошибок вход блокируется на 1 час по IP и логину. Для снятия обратитесь к администратору.</p>
            </div>
            <div class="help-item mt-4">
                <strong>2FA: Google Authenticator и SMS</strong>
                <p class="small text-muted mt-2">Если код не приходит, проверьте приложение и свяжитесь с поддержкой.</p>
            </div>
        </div>

        <div class="card">
            <h3>FAQ и инструкции</h3>
            <div class="faq-item mt-4">
                <strong>Что делать при блокировке?</strong>
                <p class="small text-muted mt-2">Обратитесь к администратору. Если вы не помните пароль, воспользуйтесь формой восстановления.</p>
            </div>
            <div class="faq-item mt-4">
                <strong>Как восстановить доступ без пароля?</strong>
                <p class="small text-muted mt-2">Напишите в поддержку с указанием логина и контакта. Специалист поможет безопасно восстановить доступ.</p>
            </div>
        </div>
        
        <!-- Блок успеха -->
        <div class="alert alert-success" id="supportSuccess" style="display:none;">
            <span class="icon">✓</span>
            <div>
                <strong>Отправка успешна</strong><br>
                Обращение принято. Ответ будет направлен на указанный контакт.
            </div>
        </div>
    </div>
</div>

<?php require 'footer.php'; ?>