<?php require 'header.php'; ?>

<div class="card max-width-600 mx-auto">
    <div class="step-badge">🛡️ Регистрация пользователя</div>
    <h2>Создайте учётную запись</h2>
    <p class="text-muted mt-2 mb-4">Логин и пароль обязательны. После регистрации пользователь получит роль Пользователь. Права Администратора назначает только администратор.</p>

    <?php if (isset($_SESSION['reg_error'])): ?>
        <div class="alert alert-error">
            <span class="icon">✕</span>
            <div>
                <strong>Ошибка регистрации</strong><br>
                <?= $_SESSION['reg_error']; unset($_SESSION['reg_error']); ?>
            </div>
        </div>
    <?php endif; ?>

    <?php if (isset($_SESSION['reg_success'])): ?>
        <div class="alert alert-success">
            <span class="icon">✓</span>
            <div>
                <strong>Успешная регистрация</strong><br>
                Учётная запись создана. Для входа подтвердите личность с помощью 2FA.
            </div>
        </div>
    <?php endif; ?>

    <form action="auth.php" method="POST">
        <div class="form-group">
            <label>Логин</label>
            <input type="text" name="reg_username" placeholder="user123" required>
            <span class="hint">Будет использоваться для входа в систему.</span>
        </div>
        <div class="form-group">
            <label>Пароль</label>
            <input type="password" name="reg_password" required>
            <span class="hint">Минимум 6 символов, минимум одна цифра, заглавная A-Z и строчная a-z.</span>
        </div>
        <div class="form-group">
            <label>Подтверждение пароля</label>
            <input type="password" name="reg_password_confirm" required>
            <span class="hint">Повторите пароль для проверки.</span>
        </div>
        <div class="form-group">
            <label>Телефон для SMS</label>
            <input type="text" name="reg_phone" placeholder="+7 (___) ___-__-__">
            <span class="hint">Используется для SMS-подтверждения 2FA.</span>
        </div>

        <!-- Блок выбора роли удален -->

        <div class="form-group mt-4">
            <label>2FA</label>
            <div class="radio-card active">
                <input type="radio" name="2fa" value="totp" checked>
                <div>
                    <strong>Google Authenticator</strong>
                    <p class="small text-muted">TOTP-код из приложения.</p>
                </div>
            </div>
            <div class="radio-card">
                <input type="radio" name="2fa" value="sms">
                <div>
                    <strong>SMS на зарегистрированный телефон</strong>
                    <p class="small text-muted">Код подтверждения приходит на указанный номер.</p>
                </div>
            </div>
        </div>

        <div class="checkbox-group mt-4 mb-4">
            <label style="display:flex; align-items:center; gap:10px; font-size:13px; cursor:pointer;">
                <input type="checkbox" required checked style="width:16px; height:16px; accent-color:var(--accent-color);">
                Уникальность логина проверяется системой при создании учётной записи.
            </label>
        </div>

        <button type="submit" class="btn btn-primary full-width">Создать учётную запись</button>
    </form>
</div>

<?php require 'footer.php'; ?>