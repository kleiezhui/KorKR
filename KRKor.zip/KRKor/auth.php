<?php
session_start();

// Загрузка пользователей
$users = json_decode(file_get_contents('users.json'), true);

// --- ОБРАБОТКА РЕГИСТРАЦИИ ---
if (isset($_POST['reg_username'])) {
    $username = trim($_POST['reg_username']);
    $password = $_POST['reg_password'];
    $confirm = $_POST['reg_password_confirm'];

    // Проверка паролей
    if ($password !== $confirm) {
        $_SESSION['reg_error'] = "Пароли не совпадают.";
        header('Location: register.php');
        exit;
    }

    // Проверка сложности пароля (минимум 6, 1 цифра, 1 заглавная, 1 строчная)
    if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{6,}$/', $password)) {
        $_SESSION['reg_error'] = "Пароль не соответствует политике безопасности.";
        header('Location: register.php');
        exit;
    }

    // Проверка на существование
    foreach ($users as $u) {
        if ($u['username'] === $username) {
            $_SESSION['reg_error'] = "Логин уже используется. Выберите другой логин и повторите регистрацию.";
            header('Location: register.php');
            exit;
        }
    }

    // Добавление нового пользователя
    $users[] = [
        'username' => $username,
        'password' => password_hash($password, PASSWORD_DEFAULT),
        'role' => 'Пользователь',
        'blocked' => false
    ];
    file_put_contents('users.json', json_encode($users));
    
    $_SESSION['reg_success'] = true;
    header('Location: register.php');
    exit;
}

// --- ОБРАБОТКА ВХОДА ---
if (isset($_POST['username'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $captcha_solved = $_POST['captcha_solved'] ?? 'false';

    if ($captcha_solved !== 'true') {
        $_SESSION['error'] = "Капча не решена. Соберите пазл.";
        header('Location: index.php');
        exit;
    }

    // Инициализация попыток
    if (!isset($_SESSION['login_attempts'])) {
        $_SESSION['login_attempts'] = 0;
    }

    // Проверка на блокировку
    $isBlocked = false;
    foreach ($users as $u) {
        if ($u['username'] === $username) {
            if ($u['blocked']) $isBlocked = true;
            break;
        }
    }

    if ($isBlocked || $_SESSION['login_attempts'] >= 3) {
        $_SESSION['blocked'] = "Вы заблокированы. Обратитесь к администратору";
        header('Location: index.php');
        exit;
    }

    // Проверка логина и пароля
    $authenticated = false;
    foreach ($users as $u) {
        if ($u['username'] === $username && password_verify($password, $u['password'])) {
            $authenticated = true;
            $_SESSION['user'] = $u['username'];
            $_SESSION['role'] = $u['role'];
            $_SESSION['login_attempts'] = 0; // Сброс попыток при успехе
            break;
        }
    }

    if ($authenticated) {
        // Перенаправление на главную с успехом (в реальном проекте - дашборд)
        header('Location: index.php?success=1');
    } else {
        $_SESSION['login_attempts']++;
        if ($_SESSION['login_attempts'] >= 3) {
            // Блокируем пользователя
            foreach ($users as &$u) {
                if ($u['username'] === $username) {
                    $u['blocked'] = true;
                }
            }
            file_put_contents('users.json', json_encode($users));
            $_SESSION['blocked'] = "Вы заблокированы. Обратитесь к администратору";
        } else {
            $_SESSION['error'] = "Вы ввели неверный логин или пароль. Пожалуйста проверьте ещё раз введенные данные";
        }
        header('Location: index.php');
    }
    exit;
}
?>