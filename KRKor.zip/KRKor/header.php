<?php
session_start();
// Инициализация имитации БД
if (!file_exists('users.json')) {
    file_put_contents('users.json', json_encode([
        ['username' => 'admin', 'password' => password_hash('Password123', PASSWORD_DEFAULT), 'role' => 'Администратор', 'blocked' => false]
    ]));
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Peace - ИС управления салоном связи</title>
    <!-- Подключение современных шрифтов -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="style.css">
    <script src="script.js" defer></script>
</head>
<body>
    <header class="main-header">
        <div class="logo">
            <img src="https://img.icons8.com/color/48/globe--v1.png" alt="Logo">
            <div>
                <h1>Peace</h1>
                <span>ИС управления салоном связи</span>
            </div>
        </div>
        <div class="header-controls">
            <div class="contact-info">
                <span>Свяжитесь с нами</span>
                <strong>8(923)4887582</strong>
            </div>
            <label class="theme-switch">
                <input type="checkbox" id="themeToggle">
                <span class="slider"></span>
            </label>
            <?php if (basename($_SERVER['PHP_SELF']) == 'index.php'): ?>
                <a href="register.php" class="btn btn-primary">Регистрация</a>
            <?php else: ?>
                <a href="index.php" class="btn btn-primary">Вход</a>
            <?php endif; ?>
        </div>
    </header>
    <main class="container">