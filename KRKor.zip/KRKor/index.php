<?php require 'header.php'; ?>

<div class="grid-2-col">
    <div class="card">
        <div class="step-badge">Шаг 1 из 2</div>
        <h2 class="text-center">Вход в систему Peace</h2>
        <p class="text-center text-muted small mt-2 mb-4">Введите учетные данные для входа</p>

        <form action="auth.php" method="POST" id="loginForm">
            <div class="form-group">
                <label>Логин *</label>
                <input type="text" name="username" placeholder="Введите логин" required>
            </div>
            <div class="form-group">
                <label>Пароль *</label>
                <input type="password" name="password" id="passwordInput" placeholder="Введите пароль" required>
            </div>

            <!-- Капча (Пазл) -->
            <div class="captcha-container">
                <p class="text-center small mb-4">Соберите пазл: расставьте фрагменты в правильном порядке</p>
                <div class="puzzle-info">Попытки: <span id="puzzle-attempts">1 / 3</span></div>
                
                <div class="puzzle-area">
                    <div class="puzzle-box">
                        <p>Сложите картинку:</p>
                        <div class="puzzle-grid" id="puzzle-grid"></div>
                    </div>
                    <div class="puzzle-box">
                        <p>Исходные фрагменты:</p>
                        <div class="puzzle-pool" id="puzzle-pool"></div>
                    </div>
                </div>

                <button type="button" class="btn btn-outline" style="padding: 6px 16px; font-size: 13px;" onclick="resetPuzzle()">↺ Обновить пазл</button>
                <input type="hidden" name="captcha_solved" id="captchaSolved" value="false">
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-success" id="btnLogin" disabled>Войти</button>
                <a href="register.php" class="btn btn-outline">Регистрация</a>
            </div>
        </form>
    </div>

    <div class="sidebar">
        <div class="card">
            <div class="step-badge">Шаг 2 из 2</div>
            <h3>Двухфакторная аутентификация</h3>
            <p class="text-muted small mt-2">Введите 6-значный код из Google Authenticator или SMS</p>
            
            <div class="tabs mt-4">
                <button type="button" class="tab active">Google Authenticator</button>
                <button type="button" class="tab">SMS-код</button>
            </div>

            <p class="small mt-2">Код подтверждения</p>
            <div class="otp-inputs">
                <input type="text" maxlength="1" class="otp-input">
                <input type="text" maxlength="1" class="otp-input">
                <input type="text" maxlength="1" class="otp-input">
                <input type="text" maxlength="1" class="otp-input">
                <input type="text" maxlength="1" class="otp-input">
                <input type="text" maxlength="1" class="otp-input">
            </div>
            <p class="text-muted small text-center mt-2">Не пришел код? <a href="#" style="color:var(--accent-color)">Отправить повторно</a> через 58 сек.</p>
            <button class="btn btn-success full-width mt-4">Подтвердить</button>
        </div>

        <div class="card info-states">
            <h4>Информационные состояния</h4>
            <p class="text-muted small mt-2 mb-4">(отображается одно активное состояние)</p>
            
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-error">
                    <span class="icon">!</span>
                    <div>
                        <strong>Ошибка входа</strong><br>
                        <?= $_SESSION['error']; unset($_SESSION['error']); ?>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['blocked'])): ?>
                <div class="alert alert-warning">
                    <span class="icon">⚠</span>
                    <div>
                        <strong>Аккаунт заблокирован</strong><br>
                        <?= $_SESSION['blocked']; unset($_SESSION['blocked']); ?>
                    </div>
                </div>
            <?php endif; ?>

            <div class="alert alert-success" id="successState" style="display:none;">
                <span class="icon">✓</span>
                <div>
                    <strong>Успешная авторизация</strong><br>
                    Вы успешно авторизовались
                </div>
            </div>
        </div>

        <div class="card">
            <h4>Политика паролей</h4>
            <p class="small text-muted mt-2">Смена пароля каждые 3 месяца. Нельзя использовать 3 последних пароля. После 3 ошибок — блокировка на 1 час.</p>
        </div>
    </div>
</div>

<?php require 'footer.php'; ?>